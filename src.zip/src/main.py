import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import numpy as np

from preprocess_image import resize_image
from model import image_captioning_model, NKDGNN, PredictionModule, CaptionGenerator, get_node_probabilities, loss_function
from knowledge_graph import build_knowledge_graph,convert_networkx_to_data
from template_caption import generate_template_caption

# Example usage
input_dim = 1
hidden_dim = 64
output_dim = 32
num_layers = 3

# Instantiate the model
model = NKDGNN(input_dim, hidden_dim, output_dim, num_layers)
prediction_module = PredictionModule(output_dim)

optimizer = torch.optim.Adam(list(model.parameters()) + list(prediction_module.parameters()), lr=0.01)

# Training function
def train(model, prediction_module, data_loader, optimizer):
    model.train()
    prediction_module.train()
    for data in data_loader:
        optimizer.zero_grad()
        Nr = model(data)
        y_hat = prediction_module(data.x, Nr)
        loss = loss_function(y_hat, data.y)
        loss.backward()
        optimizer.step()

def predict(model, prediction_module, data, template):
    node_probabilities = get_node_probabilities(model, prediction_module, data)
    print("Node Probabilities:", node_probabilities)
    generator = CaptionGenerator(model, prediction_module)
    generated_caption = generator.predict_caption(data, template)
    print("Generated Caption:", generated_caption)